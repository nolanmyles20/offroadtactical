# Tactical Offroad — v6 (Cross-Karts + Coming Soon)

- Adds CROSS-KARTS to the menu and homepage featured lineup.
- Cross-Karts products are "simple" with a single variant ("Solo").
- Image for Cross-Karts uses /assets/coming-soon.svg.
- Other platforms keep Armor/Stainless + thickness + powdercoat selectors on the card.
- Add-to-cart builds Shopify cart URLs from products.json variant_ids mapping.
